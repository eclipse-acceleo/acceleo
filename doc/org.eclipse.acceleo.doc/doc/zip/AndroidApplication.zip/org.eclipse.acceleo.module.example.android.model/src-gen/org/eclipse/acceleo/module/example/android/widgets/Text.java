/**
 * <copyright>
 * </copyright>
 *
 * $Id: Text.java,v 1.1 2010/03/30 12:57:34 jmusset Exp $
 */
package org.eclipse.acceleo.module.example.android.widgets;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Text</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.acceleo.module.example.android.widgets.WidgetsPackage#getText()
 * @model
 * @generated
 */
public interface Text extends Widget {
} // Text
