/**
 * <copyright>
 * </copyright>
 *
 * $Id: Button.java,v 1.1 2010/03/30 12:57:34 jmusset Exp $
 */
package org.eclipse.acceleo.module.example.android.widgets;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Button</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.acceleo.module.example.android.widgets.WidgetsPackage#getButton()
 * @model
 * @generated
 */
public interface Button extends Widget {
} // Button
